
const Info = () => {
    return (
        <>
            
        </>
    );
};

export default Info;
